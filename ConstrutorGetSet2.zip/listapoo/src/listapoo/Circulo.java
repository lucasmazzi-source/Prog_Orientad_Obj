/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package listapoo;

/**
 *
 * @author lucas mazzi
 */

class Circulo {
    private float raio;
    private String Nome;
    
    public Circulo(String Nome, float raio){
        this.raio = raio;
        this.Nome = Nome;

    }

    public float getRaio() {
        return raio;
    }

    public String getNome() {
        return Nome;
    }

    public void setRaio(float raio) {
        this.raio = raio;
    }

    public void setNome(String Nome) {
        this.Nome = Nome;
    }


    float Area(){
        
            return 3.14f * (raio * raio);
    }
    
    float Circunferencia(){
        return 2 * 3.14f * raio;
    }
    
    void Dados(){
        System.out.printf("Nome do circulo : \n",this.Nome);
            System.out.printf("Raio circulo: %.2f\n", this.raio);
            System.out.printf("Area do circulo : %.2f\n", this.Area());
            System.out.printf("Circunferencia do circulo: %.2f\n", this.Circunferencia());
            
    }
}



    

