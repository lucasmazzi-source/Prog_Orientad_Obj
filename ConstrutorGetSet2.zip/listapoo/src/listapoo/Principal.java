/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package listapoo;

/**
 *
 * @author pck
 */
public class Principal {

    public static void main(String[] args) {
        Circulo c = new Circulo("Circulo 1", 5.0f);
        Circulo c2 = new Circulo("Circulo 2", 9.25f);
    
        
        c.Dados();
        c2.Dados(); 
        
        if (c.getRaio() > c2.getRaio()) {
    System.out.printf("O círculo com o maior raio eh: %s\n", c.getNome());
} else {
    System.out.printf("O círculo com o maior raio eh: %s\n", c2.getNome());
}
    }        

}