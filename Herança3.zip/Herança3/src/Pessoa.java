/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author lucas mazzi
 */
public class Pessoa {
    String nome;
    String cpf;

    public Pessoa() { //Construtor padrao
    }

    public Pessoa(String nome, String cpf) {
        this.nome = nome;
        this.cpf = cpf;
    }
    
    
    void Dados(){
        System.out.printf("Nome :  %s\n", nome);
        System.out.printf("CPF : %s\n",cpf);
    }
}
