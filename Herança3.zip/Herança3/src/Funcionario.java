/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author aluno
 */
public class Funcionario extends Pessoa{
    int matricula;
    float salario;
    void Dados(){
        super.Dados();
        System.out.printf("Matricula : %d\n",matricula);
        System.out.printf("Salario : %.2f\n",salario);
    }
}
