/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author lucas mazzi
 */
public class Cliente extends Pessoa{
    String perfil; 

    public Cliente(String nome, String cpf, String perfil) {
        super(nome, cpf); // Construtor Super Classe ( PESSOA ) 
        this.perfil = perfil;
    }
    
    
    void Dados() { //reescrita metodo dados//
      super.Dados(); 
        System.out.printf("Perfil : %s\n", perfil);
}
}