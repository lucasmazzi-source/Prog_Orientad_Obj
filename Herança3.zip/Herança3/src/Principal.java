/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author lucas mazzi
 */
public class Principal {
    public static void main(String[] args) {
             Cliente c = new Cliente("Adao", "123.456.789-01", "Investidor" );
             c.Dados();
             
             Gerente ge = new Gerente();
             ge.nome = "Gerentilso";
             ge.cpf = "098.765.432-10";
             ge.matricula = 1987;
             ge.salario = 2785.90f;
             ge.setor  =  "Auxiliar de bico";  
             ge.Dados();
             
             Caixa ca = new Caixa();
             ca.nome = "lula";
             ca.cpf = "135.234.567-09";
             ca.numeroCaixa = 8;
             ca.matricula = 8762;
             ca.salario = 2200.75f;
             ca.Dados();
}
    
    
}