/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author aluno
 */
public class Caixa extends Funcionario {
  int numeroCaixa;

    @Override
    void Dados() {
        super.Dados();
        
        System.out.printf("Numero do caixa : %d\n",numeroCaixa);
    }

    
}