/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author lucas mazzi
 */
public class Gerente extends Funcionario {
    
    String setor;
   
    void Dados() {
        super.Dados() ; //nome e cpf 
        
        System.out.printf("Setor : %s\n",setor);
 
         
    }
}
