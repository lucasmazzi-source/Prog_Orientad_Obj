/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author lucas m
 */
public class Pessoa{
    String nome;
    String cpf;
    
    void Dados(){
        System.out.printf("Nome : %s\n",nome);
        System.out.printf("CPF : %s\n", cpf);
    }
    
    
}
