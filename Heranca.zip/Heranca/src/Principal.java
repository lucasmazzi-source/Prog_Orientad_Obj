/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author aluno
 */
public class Principal {
    public static void main(String[] args) {
        Pessoa p = new Pessoa();
        p.nome = "Lucas";
        p.cpf = ("123.456.789-01");
        p.Dados();
       
        
        
        Cliente c = new Cliente();
        c.nome = "Lula";
        c.cpf = "098.765.432-21";
        c.perfil = "Investidor";
        c.dados();
    }
}
