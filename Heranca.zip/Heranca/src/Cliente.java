/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author aluno
 */
public class Cliente extends Pessoa{
   String perfil;
   void dados(){
     
       super.Dados();
        System.out.printf("Perfil : %s\n", perfil);
   }
    
}
