import java.util.ArrayList;

public class Principal {
    public static void main(String[] args) {

        
        ArrayList<String> lista = new ArrayList<>();
        lista.add("Ana");
        lista.add("Bruno");
        lista.add("Carla");
        System.out.printf("Lista de nomes: %s%n", lista);
        System.out.printf("Segundo nome: %s%n", lista.get(1));
        lista.remove("Bruno");
        System.out.printf("Depois de remover: %s%n", lista);

        
        ArrayList<Pessoa> pessoas = new ArrayList<>();

       
        pessoas.add(new Pessoa("Lucas", 18));
        pessoas.add(new Pessoa("Maria", 20));
        pessoas.add(new Pessoa("João", 25));

        
        Pessoa primeira = pessoas.get(0);
        System.out.printf("%nPrimeira pessoa: %s - %d anos%n", primeira.getNome(), primeira.getIdade());

        
        pessoas.remove(1);

        
        System.out.printf("%nLista de pessoas:%n");
        for (Pessoa pessoa : pessoas) {
            System.out.printf("%s - %d anos%n", pessoa.getNome(), pessoa.getIdade());
        }
        System.out.printf("Total: %d%n", pessoas.size());
    }
}
