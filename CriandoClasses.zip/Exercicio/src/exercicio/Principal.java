/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package exercicio;

/**
 *
 * @author lucas mazzi
 */
public class Principal { 
    
    public static void main(String[] args) {
        Aluno a = new Aluno();
        a.nomeAluno = "lucas";
        a.nota1 = 6.6;
        a.nota2 = 5.97;
        a.dados();
        a.mediafinal();
        
    }
    
}
