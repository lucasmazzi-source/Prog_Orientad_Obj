
package exercicio;

/**
 *
 * @author lucas mazzi
 */
public class Aluno {
 //Atributos 
    
    String nomeAluno;
    double nota1;
    double nota2;
    double mediafinal;
 //comportamentos//
    void dados(){
        
        
        
        System.out.printf("Nome do aluno : %s\n", nomeAluno);
        System.out.printf("Nota 1 Aluno: %.2f\n", nota1);
        System.out.printf("Nota 2 Aluno: %.2f\n", nota2);
       
        
    }
    
    void mediafinal(){
        mediafinal = (nota1 + nota2) / 2;
        
        System.out.printf("Media final: %.2f", mediafinal);
        
        
    }
    
  public static void main(String[] args) {
        
    }
    
}
