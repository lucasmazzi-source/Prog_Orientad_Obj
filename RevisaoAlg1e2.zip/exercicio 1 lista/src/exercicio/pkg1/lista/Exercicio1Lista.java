

package exercicio.pkg1.lista;

/**
 *
 * @author lucas mazzi
 */
public class Exercicio1Lista {

    public static double calcular_media(double n1, double n2) {

        return (n1 + n2) / 2;
    }

    public static double celsius_para_fahrenheit(double celsius) {

        return celsius * 1.8 + 32;
    }

    public static int calcular_fatorial(int num1) {

        int fatorial1 = 1;

        for (int i = 1; i <= num1; i++) {
            fatorial1 = fatorial1 * i;
        }

        return fatorial1;

    }

    public static int somar_intervalo(int inicio, int fim) {

        int soma = 0;
        for (int i = inicio; i <= fim; i++) {
            soma = soma + i;
        }

        return soma;

    }
    
    public class Main {

    static boolean ehPrimo(int n) {
        if (n <= 1) return false;
        for (int i = 2; i * i <= n; i++) {
            if (n % i == 0) return false;
        }
        return true;
    }


    static void primeiros_primos(int x) {
        int contador = 0;
        int numero = 2;
        
        System.out.printf("Os %d primeiros números primos são: ", x);
        
        while (contador < x) {
            if (ehPrimo(numero)) {
                System.out.printf("%d", numero);
                contador++;
                
                if (contador < x) {
                    System.out.printf(", ");
                }
            }
            numero++;
        }
        System.out.printf(".\n");
    }

   
}

    
    

    public static void main(String[] args) {

        //teste exercicio 1 // 
        double media = calcular_media(6, 7);
        System.out.printf("Média: %.1f\n", media);

        //teste exercicio 2 //  
        double conversao = celsius_para_fahrenheit(25.6);
        System.out.printf("Conversão: %.2f\n", conversao);

        //teste exercico 3 // 
        int numfatorial = calcular_fatorial(5);
        System.out.printf("Fatorial: %d\n", numfatorial);

        //teste exercicio 4 // 
        int somarIntervalo = somar_intervalo(2, 5);
        System.out.printf("Soma Intervalo: %d\n", somarIntervalo);
        
        //teste do exercicio 5// 
       int numprimo = primeiros_primos(6);
        
        
        

    }

}