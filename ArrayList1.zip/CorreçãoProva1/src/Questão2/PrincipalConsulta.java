package Questão2;

/**
 *
 * @author lucas m
 */
public class PrincipalConsulta {
    public static void main(String[] args) {
        
        Paciente p = new Paciente("Jair", 26);
        Paciente p1 = new Paciente("Hugo", 23);
        
        Consulta c = new Consulta(
                "28/09", "Sta Casa", "Ancellotti", p);
        
        c.dados();
        
        boolean testeIdade = c.verificaIdade();
        System.out.print(testeIdade);
    }
}
