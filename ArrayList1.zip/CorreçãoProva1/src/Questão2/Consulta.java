package Questão2;

/**
 *
 * @author lucas m
 */
public class Consulta {
    private String data;
    private String local;
    private String nomeMédico;
    private Paciente paciente;

    public Consulta(String data, String local, String nomeMédico, Paciente paciente) {
        this.data = data;
        this.local = local;
        this.nomeMédico = nomeMédico;
        this.paciente = paciente;
    }
    
    public void dados(){
        System.out.printf("Consulta %s - %s\n",
                data, local);
        System.out.printf("Médico: %S\n", 
                nomeMédico);
        System.out.print("Paciente:\n");
        //versão 1
        System.out.printf("Nome: %S - %d anos\n",
                paciente.getNome(),
                paciente.getIdade());
          
    }
    
    public boolean verificaIdade(){
        if(paciente.getIdade() >= 18 &&
           paciente.getIdade() <= 60)
            return true;
        else
            return false;
    }    

    public Paciente getPaciente() {
        return paciente;
    }

    public void setPaciente(Paciente paciente) {
        this.paciente = paciente;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public String getLocal() {
        return local;
    }

    public void setLocal(String local) {
        this.local = local;
    }

    public String getNomeMédico() {
        return nomeMédico;
    }

    public void setNomeMédico(String nomeMédico) {
        this.nomeMédico = nomeMédico;
    }

    
    
    
}