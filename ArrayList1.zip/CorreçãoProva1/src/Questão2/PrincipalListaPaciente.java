package Questão2;

import java.util.ArrayList;

/**
 *
 * @author lucas mazzi
 */
public class PrincipalListaPaciente {
    public static void main(String[] args) {

        ArrayList<Paciente> pacientes;
        pacientes = new ArrayList();
        
        Paciente p1 = new Paciente("Mario", 20);
        Paciente p2 = new Paciente("Joana", 17);
        
        pacientes.add(p1);
        pacientes.add(p2);
        pacientes.add(new Paciente("João", 19));
        pacientes.add(new Paciente("Paola", 18));
        pacientes.add(new Paciente("Jorge", 17));
        
        
        for (int i = 0; i < pacientes.size(); i++) {
            Paciente p = pacientes.get(i);
            p.dados();
        }
        
        int soma = 0;
        for (int i = 0; i < pacientes.size(); i++) {
            soma += pacientes.get(i).getIdade();
        }
        double media = (double) soma / pacientes.size();
        System.out.printf("\nMédia das idades: %.2f anos\n", media);
        
        
        Paciente maisVelho = pacientes.get(0);
        for (int i = 1; i < pacientes.size(); i++) {
            if (pacientes.get(i).getIdade() > maisVelho.getIdade()) {
                maisVelho = pacientes.get(i);
            }
        }
        System.out.println("Paciente de maior idade: " + maisVelho.getNome());
        
   
        boolean achou = false;
        for (int i = 0; i < pacientes.size(); i++) {
            Paciente p = pacientes.get(i);
            if (p.getNome().equals("João")) {
                System.out.println("\nPaciente João encontrado:");
                p.dados();
                achou = true;
                break;
            }
        }
        if (!achou) {
            System.out.println("\nPaciente João não está na lista.");
        }
    }
}
