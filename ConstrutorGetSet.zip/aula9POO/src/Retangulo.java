


/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author lucas mazzi
 */
public class Retangulo {
    double base;
    double altura;
    
    public Retangulo(double base, double altura){
        this.base = base;
        this.altura = altura;
    }

    public double setBase(double base) {
        this.base = base;
        return base;
    }

    public double setAltura(double altura) {
        this.altura = altura;
        return altura;
    }
    
    
    
    public double getBase(){
      return base;
      }
    public double getAltura(){
        return altura;
    }
    
    double Area(){
        return base * altura;
        }
    
    double Perimetro(){
        return 2 * (base + altura);
                
    }    
   void Dados(){
        System.out.printf("Base do retangulo: %.2f\n", base);
        System.out.printf("Altura do retangulo: %.2f\n", altura);
        System.out.printf("Area do retangulo: %.2f\n", Area());
        System.out.printf("Perimetro do retangulo: %.2f\n", Perimetro());
    } 
}
