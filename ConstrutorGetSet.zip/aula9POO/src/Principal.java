/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author aluno
 */
public class Principal {
    
    public static void main(String[] args) {
        
    Retangulo r1 = new Retangulo(3, 4);
    Retangulo r2 = new Retangulo(5, 6);
   
    if(r1.Area() > r2.Area()){
        r1.Dados();
        r2.Dados();
       } else {
        r2.Dados();
        r1.Dados();
    }
    
    
       }
    
    
    
    }
