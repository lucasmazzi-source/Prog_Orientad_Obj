package contacorrente;

/**
 *
 * @author lucas m
 */
public class Pessoa {

    private String nome;
    private String cpf;

    public Pessoa(String nome, String cpf) {
        this.nome = nome;
        this.cpf = cpf;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public void dados() {
        System.out.printf("nome: %s\n", this.nome);
        System.out.printf("cpf: %s\n", this.cpf);
    }

}
