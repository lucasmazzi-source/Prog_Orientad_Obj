package contacorrente;

/**
 *
 * @author lucas m
 */
public class ContaCorrente {

    private int numero;
    private float saldo;
    private Pessoa titular;

    public ContaCorrente(int numero, float saldo, Pessoa titular) {
        this.numero = numero;
        this.saldo = saldo;
        this.titular = titular;
    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public float getSaldo() {
        return saldo;
    }

    public void setSaldo(float saldo) {
        this.saldo = saldo;
    }

    public Pessoa getTitular() {
        return titular;
    }

    public void setTitular(Pessoa titular) {
        this.titular = titular;
    }

    public float sacar(float valor) {
        saldo = saldo - valor;
        return saldo;
    }

    public float depositar(float valor) {
        saldo = saldo + valor;
        return saldo;
    }

    public void extratoSimples() {
        System.out.printf("----- extrato simples -----\n");
        System.out.printf("numero da conta: %d\n", numero);
        System.out.printf("saldo: R$ %.2f\n", 
                saldo);
        System.out.printf("titular:\n");
        titular.dados();
        
    }

}
