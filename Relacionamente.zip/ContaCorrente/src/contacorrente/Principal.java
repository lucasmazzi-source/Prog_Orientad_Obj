package contacorrente;

/**
 *
 * @author lucas m
 */
public class Principal {

    public static void main(String[] args) {

        Pessoa titular = new Pessoa("joao da silva", "123.456.789-00");
         ContaCorrente conta = new ContaCorrente(1001, 500.0f, titular);
         
        Pessoa titular2 = new Pessoa("maria da silva", "987.654.321-00");
        ContaCorrente conta2 = new ContaCorrente(1234, 350.0f, titular);
        
        

        conta.extratoSimples();
        conta2.extratoSimples();
        
        conta.depositar(200.0f);
        conta2.depositar(340.0f);
        
        conta.sacar(150.0f);
        conta2.sacar(98.0f);
        
        System.out.printf("apos movimentacoes:\n");
        conta.extratoSimples();
        conta2.extratoSimples();
    }

}
