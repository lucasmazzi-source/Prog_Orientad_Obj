/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package heranca2;

/**
 *
 * @author lucas mazzi
 */
public class Caixa extends Pessoa {
    
    int matricula;
    float salario;
    int numeroCaixa;
    
    void dadosCaixa(){
        super.dados();
        System.out.printf("Matricula : %d\n", matricula);
        System.out.printf("Salario : %f\n", salario);
        System.out.printf("Numero do caixa : %d\n",numeroCaixa);
        
    }
    
}
