/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package heranca2;

/**
 *
 * @author lucas mazzi
 */
public class Principal {
    public static void main(String[] args) {
        
        Cliente c = new Cliente();
        c.nome = "Lucas";
        c.cpf = "123.456.789-01";
        c.perfil = "investidor";
        c.dados();
        
        
        Caixa ca = new Caixa();
        ca.nome = "Arthur";
        ca.cpf = "098.765.543-21";
        ca.matricula = 1234;
        ca.salario = 3500.45f;
        ca.numeroCaixa = 8;
        ca.dadosCaixa();
        
    }
    
}
