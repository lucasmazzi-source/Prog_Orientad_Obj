/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package heranca2;

/**
 *
 * @author lucas mazzi
 */
public class Cliente extends Pessoa {
    String perfil;
    void dados(){
        
        super.dados();
        System.out.printf("perfil : %s\n",perfil);
        
    }
    
}
