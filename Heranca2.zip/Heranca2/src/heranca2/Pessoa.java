/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package heranca2;

/**
 *
 * @author lucas mazzi
 */
public class Pessoa {
    String nome;
    String cpf;
    
    void dados(){
        System.out.printf("nome ; %s\n",nome);
        System.out.printf("cpf : %s\n",cpf );
    }
    }
